"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { MdClose } from "react-icons/md";
import { FiClock, FiMessageCircle, FiMinus, FiPlus } from "react-icons/fi";
import { GiCandleFlame } from "react-icons/gi";

import { useWebContext } from "@/context-api/WebContext";
import { mahaDeepamPopup as data, NightId } from "./mahaDeepamData";

const DAY = 24 * 60 * 60 * 1000;

const MahaDeepamPopup = () => {
  const pathName = usePathname();
  const { isOpenDeepamPopup, setIsOpenDeepamPopup } = useWebContext();

  const [night, setNight] = useState<NightId>("both");
  const [guests, setGuests] = useState<number>(data.guests.default);
  const [daysLeft, setDaysLeft] = useState<number | null>(null);
  const [expired, setExpired] = useState(false);

  const closeBtnRef = useRef<HTMLButtonElement>(null);
  const touchStartY = useRef<number | null>(null);

  const isLanding = pathName === "/";

  /* ---------- countdown (client only, avoids hydration mismatch) ---------- */
  useEffect(() => {
    const now = Date.now();
    const start = new Date(data.eventStart).getTime();
    const end = new Date(data.eventEnd).getTime();
    setExpired(now >= end);
    setDaysLeft(Math.ceil((start - now) / DAY));
  }, []);

  /* ---------- auto open once per session, only on the landing page ---------- */
  useEffect(() => {
    if (!isLanding || expired) return;
    try {
      if (sessionStorage.getItem(data.storageKey)) return;
    } catch {
      /* storage blocked -> still show once per page load */
    }
    const t = setTimeout(() => setIsOpenDeepamPopup(true), 1200);
    return () => clearTimeout(t);
  }, [isLanding, expired, setIsOpenDeepamPopup]);

  const close = useCallback(() => {
    setIsOpenDeepamPopup(false);
    try {
      sessionStorage.setItem(data.storageKey, "1");
    } catch {
      /* ignore */
    }
  }, [setIsOpenDeepamPopup]);

  /* ---------- esc key, scroll lock, focus ---------- */
  useEffect(() => {
    if (!isOpenDeepamPopup) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeBtnRef.current?.focus();
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [isOpenDeepamPopup, close]);

  /* ---------- swipe down on the handle closes the mobile sheet ---------- */
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartY.current === null) return;
    if (e.changedTouches[0].clientY - touchStartY.current > 70) close();
    touchStartY.current = null;
  };

  /* ---------- whatsapp link ---------- */
  const whatsappHref = useMemo(() => {
    const selected = data.nights.find((n) => n.id === night)!;
    const text = `Hi Anantharaa Team,

I'd like to check room availability for Maha Deepam (Karthigai Deepam).

Nights: ${selected.full}
Guests: ${guests}

Please share the available rooms and rates.

Thank you!`;
    return `https://wa.me/${data.whatsapp}?text=${encodeURIComponent(text)}`;
  }, [night, guests]);

  if (expired || pathName === "/thank-you/") return null;

  const countdownLabel =
    daysLeft === null
      ? ""
      : daysLeft > 1
        ? `${daysLeft} days to the Deepam`
        : daysLeft === 1
          ? "Deepam is tomorrow"
          : "Deepam is here";

  return (
    <section
      role="dialog"
      aria-modal="true"
      aria-label="Maha Deepam room booking"
      aria-hidden={!isOpenDeepamPopup}
      className={`fixed inset-0 z-[60] flex items-end justify-center bg-black/60 backdrop-blur-sm transition-opacity duration-300 md:items-center md:p-6 ${
        isOpenDeepamPopup
          ? "visible opacity-100"
          : "invisible pointer-events-none opacity-0"
      }`}
      onClick={close}
    >
      {/* ================= PANEL ================= */}
      <div
        onClick={(e) => e.stopPropagation()}
        className={`relative flex w-full flex-col bg-dark text-background shadow-2xl transition-all duration-500 ease-out hide-scroll
          max-h-[92dvh] max-w-md overflow-y-auto rounded-t-[28px]
          md:max-h-[90dvh] md:max-w-[940px] md:flex-row md:overflow-hidden md:rounded-2xl
          ${isOpenDeepamPopup ? "translate-y-0 md:scale-100" : "translate-y-full md:translate-y-4 md:scale-95"}`}
      >
        {/* close */}
        <button
          ref={closeBtnRef}
          onClick={close}
          aria-label="Close"
          className="absolute right-4 top-4 z-20 flex size-11 items-center justify-center rounded-full border border-background/30 bg-black/40 text-background transition hover:bg-black/70 active:scale-95"
        >
          <MdClose className="text-xl" />
        </button>

        {/* ---------- LEFT / TOP : image ---------- */}
        <div className="relative h-[230px] shrink-0 md:h-auto md:min-h-[600px] md:w-[400px]">
          <Image
            src={data.image}
            alt="Annamalaiyar Temple gopuram lit up for Karthigai Deepam"
            fill
            sizes="(max-width: 768px) 100vw, 400px"
            className="object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-dark md:to-black/70" />

          {/* mobile drag handle */}
          <div
            className="absolute inset-x-0 top-0 z-10 flex justify-center pb-6 pt-3 md:hidden"
            onTouchStart={onTouchStart}
            onTouchEnd={onTouchEnd}
          >
            <span className="h-1 w-10 rounded-full bg-background/50" />
          </div>

          {/* desktop : mantra + place */}
          <div className="absolute left-8 top-8 hidden md:block">
            <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-background2">
              {data.mantra}
            </p>
            <p className="mt-1 font-secondary text-[26px] font-semibold uppercase leading-none tracking-wide text-background">
              {data.place}
            </p>
          </div>

          {/* mobile : mantra + title + date */}
          <div className="absolute inset-x-5 bottom-3 md:hidden">
            <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-background2">
              {data.mantra} · {data.place}
            </p>
            <div className="mt-1 flex items-end justify-between gap-3">
              <h2 className="font-secondary text-[40px] font-semibold leading-none tracking-wide text-background2 [font-variant:small-caps]">
                {data.title}
              </h2>
              <div className="shrink-0 rounded-md bg-background px-2.5 py-1 text-center text-p1">
                <p className="font-secondary text-lg font-semibold leading-none">
                  {data.dateBig}
                </p>
                <p className="mt-0.5 text-[9px] font-bold uppercase tracking-[0.15em]">
                  {data.dateSmallMobile}
                </p>
              </div>
            </div>
          </div>

          {/* desktop : countdown + thumbnail card */}
          <div className="absolute inset-x-6 bottom-6 hidden space-y-3 md:block">
            {countdownLabel && (
              <span className="inline-flex items-center gap-2 rounded-full border border-background/40 bg-black/50 px-3.5 py-2 text-xs font-semibold text-background backdrop-blur">
                <GiCandleFlame className="text-background2" />
                {countdownLabel}
              </span>
            )}
            <div className="flex items-center gap-3 rounded-xl border border-background/15 bg-black/55 p-2 backdrop-blur">
              <div className="relative h-[68px] w-[104px] shrink-0 overflow-hidden rounded-lg">
                <Image
                  src={data.thumb.image}
                  alt={data.thumb.title}
                  fill
                  sizes="104px"
                  className="object-cover"
                />
              </div>
              <div>
                <p className="font-secondary text-xl font-medium italic leading-tight text-background">
                  {data.thumb.title}
                </p>
                <p className="mt-1 text-xs font-medium text-background2">
                  {data.thumb.caption}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ---------- RIGHT / BOTTOM : content ---------- */}
        <div className="flex min-w-0 flex-1 flex-col">
          {/* story */}
          <div className="px-5 pb-6 pt-5 md:px-12 md:pb-8 md:pt-10">
            <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] text-background">
              <span className="size-1.5 rounded-full bg-background" />
              <span className="md:hidden">{data.eyebrowMobile}</span>
              <span className="max-md:hidden">{data.eyebrow}</span>
            </p>

            {/* desktop title + date */}
            <h2 className="mt-3 hidden font-secondary text-[58px] font-semibold leading-none tracking-wide text-background2 [font-variant:small-caps] md:block">
              {data.title}
            </h2>
            <div className="mt-4 hidden w-fit items-baseline gap-2 rounded bg-background px-3.5 py-2 text-p1 md:flex">
              <span className="font-secondary text-[26px] font-semibold leading-none">
                {data.dateBig}
              </span>
              <span className="text-[11px] font-bold uppercase tracking-[0.18em]">
                {data.dateSmall}
              </span>
            </div>

            <p className="mt-4 max-w-[28rem] font-secondary text-[21px] font-medium leading-snug text-background md:mt-6 md:text-2xl">
              {data.description}
            </p>

            <ul className="mt-5 grid grid-cols-3 gap-3 md:mt-7 md:gap-4">
              {data.features.map(({ icon: Icon, text }) => (
                <li
                  key={text}
                  className="flex flex-col gap-1.5 text-xs leading-snug text-background/90 md:flex-row md:items-start md:gap-2"
                >
                  <Icon className="shrink-0 text-base text-background2 md:mt-0.5" />
                  <span>{text}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* booking */}
          <div className="border-t border-background/15 bg-p2 px-5 pb-6 pt-5 md:mt-auto md:px-12 md:pb-8 md:pt-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between md:gap-6">
              {/* nights */}
              <div>
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-background/80">
                    Your nights
                  </p>
                  <p className="flex items-center gap-1.5 text-xs font-semibold text-background2 md:hidden">
                    <FiClock /> Limited rooms
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2 md:flex">
                  {data.nights.map((n) => (
                    <button
                      key={n.id}
                      type="button"
                      aria-pressed={night === n.id}
                      onClick={() => setNight(n.id)}
                      className={`h-11 rounded-lg border px-4 text-sm font-medium transition active:scale-95 ${
                        night === n.id
                          ? "border-background bg-background text-p1"
                          : "border-background/30 text-background hover:border-background/70"
                      }`}
                    >
                      {n.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* guests */}
              <div className="flex items-center justify-between md:block">
                <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-background/80 md:mb-3">
                  Guests
                </p>
                <div className="flex h-11 w-[118px] items-center justify-between rounded-lg border border-background/30 px-1.5 md:w-[118px]">
                  <button
                    type="button"
                    aria-label="Decrease guests"
                    disabled={guests <= data.guests.min}
                    onClick={() => setGuests((g) => Math.max(data.guests.min, g - 1))}
                    className="flex size-8 items-center justify-center rounded text-background disabled:opacity-30"
                  >
                    <FiMinus />
                  </button>
                  <span className="text-sm font-semibold" aria-live="polite">
                    {guests}
                  </span>
                  <button
                    type="button"
                    aria-label="Increase guests"
                    disabled={guests >= data.guests.max}
                    onClick={() => setGuests((g) => Math.min(data.guests.max, g + 1))}
                    className="flex size-8 items-center justify-center rounded text-background disabled:opacity-30"
                  >
                    <FiPlus />
                  </button>
                </div>
              </div>
            </div>

            <Link
              href={whatsappHref}
              target="_blank"
              rel="noreferrer"
              onClick={close}
              className="mt-5 flex h-[54px] w-full items-center justify-center gap-2.5 rounded-lg bg-background text-base font-semibold text-p1 transition hover:brightness-105 active:scale-[0.99]"
            >
              <FiMessageCircle className="text-xl" />
              Check availability on WhatsApp
            </Link>

            <div className="mt-4 flex flex-col items-center gap-2 text-xs text-background/90 md:flex-row md:justify-between">
              <p>
                <span className="md:hidden">Or call </span>
                <span className="max-md:hidden">Prefer to call? </span>
                {data.phones.map((p, i) => (
                  <span key={p.href}>
                    {i > 0 && " · "}
                    <a href={p.href} className="font-semibold text-background underline">
                      {p.label}
                    </a>
                  </span>
                ))}
              </p>
              <p className="flex items-center gap-1.5 font-semibold text-background2 max-md:hidden">
                <FiClock /> Limited rooms
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MahaDeepamPopup;