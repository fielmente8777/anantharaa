import type { IconType } from "react-icons";
import { FiHeadphones, FiMapPin } from "react-icons/fi";
import { LuBedDouble } from "react-icons/lu";

export type NightId = "23" | "24" | "both";

export interface NightOption {
  id: NightId;
  label: string; // shown on the chip
  full: string; // used inside the WhatsApp message
}

export const mahaDeepamPopup = {
  // sessionStorage key -> popup auto-opens only once per visit
  storageKey: "anantharaa-maha-deepam-popup-seen",
  // IST, so the countdown is correct for every visitor
  eventStart: "2026-11-23T00:00:00+05:30",
  eventEnd: "2026-11-25T00:00:00+05:30",

  mantra: "Om Namah Shivaya",
  place: "Thiruvannamalai",
  eyebrow: "Karthigai Deepam · Bookings now open",
  eyebrowMobile: "Karthigai Deepam · Bookings open",
  title: "Maha Deepam",
  dateBig: "23 & 24",
  dateSmall: "November 2026",
  dateSmallMobile: "Nov 2026",
  description:
    "Witness the sacred flame light up Arunachala, then rest easy after your darshan — just steps from the temple.",

  image: "/maha-deepam/temple.jpg",
  thumb: {
    image: "/maha-deepam/gopuram-window.jpg",
    title: "The gopuram, from our window",
    caption: "Annamalaiyar Temple · 2-min walk",
  },

  features: [
    { icon: FiMapPin as IconType, text: "2-min walk to the temple" },
    { icon: LuBedDouble as IconType, text: "Clean, hygienic rooms" },
    { icon: FiHeadphones as IconType, text: "24×7 guest assistance" },
  ],

  nights: [
    { id: "23", label: "23 Nov", full: "23 Nov 2026" },
    { id: "24", label: "24 Nov", full: "24 Nov 2026" },
    { id: "both", label: "Both nights", full: "23 & 24 Nov 2026 (both nights)" },
  ] as NightOption[],

  guests: { min: 1, max: 10, default: 2 },

  whatsapp: "919585999301",
  phones: [
    { label: "95859 99301", href: "tel:+919585999301" },
    { label: "94038 92144", href: "tel:+919403892144" },
  ],
};