import { contact } from "@/utils/constent";

export const navData = {
  logo: "/logo1.png",

  buttons: [
    { label: "Call Us", href: contact.callCta },
    { label: "Book Now", href: contact.WhatsappCta },
  ],

  links: [
    { label: "About", href: "#about" },
    { label: "Events", href: "#events" },
    { label: "Why Choose Us", href: "#why-choose-us" },
    { label: "Gallery", href: "#gallery" },
  ],
};

export const WebsiteNavData = {
  logo: "/images/logo.png",
  links: [
    { label: "Home", href: "/" },
    { label: "About", href: "/about-us/" },
   
  ],
};
