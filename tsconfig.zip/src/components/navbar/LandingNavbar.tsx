"use client";
import Image from "next/image";
import Link from "next/link";
import { CalendarIcon, CallIcon, WhatsAppIcon } from "../buttons/LinkButton";
import { navData } from "./navData";
import { usePathname } from "next/navigation";
import { contact2 } from "@/utils/constent";

const LandingNavbar = () => {
  const pathName = usePathname();
  // const scrollToSection = (id: string) => {
  //   const element = document.getElementById(id);
  //   if (element) {
  //     element.scrollIntoView({ behavior: "smooth" });
  //   }
  //   return;
  // };

  if (pathName === "/thank-you/") {
    return null;
  }


  const isSonagiri = pathName === "/sonagiriserene/";
  const navButtons = isSonagiri
    ? [
        { label: navData.buttons[0].label, href: contact2.callCta },
        { label: navData.buttons[1].label, href: contact2.WhatsappCta },
      ]
    : navData.buttons;

  return (
    <header className="max_screen_width w-full bg-background">

      <nav className="max_width">
        <div className="flex py-1 md:py-3 w-full items-center justify-between">
          {/* LOGO */}
          {/* <div>
            <div className="relative aspect-[2.2/1.25] md:aspect-[4/2.25] w-40 md:w-45">
              <Image
                src={navData.logo}
                alt="The Anantharaa Hotel Logo"
                fill
                priority
                className="object-cover rounded-md"
              />
            </div>
          </div> */}
          {/* LOGO */}
          <div>
            {isSonagiri ? (
              <h2 className="font-secondary text-[#6C594F] text-3xl md:text-4xl font-medium text-center leading-none tracking-[0.12em]">
                SONAGIRI
                <span className="block w-[40%] h-[1px] bg-[#6C594F]/70 mx-auto my-1 md:my-1.5" />
                <span className="block font-inter text-[#6C594F] text-sm md:text-base font-medium tracking-[0.28em]">
                  SERENE
                </span>
              </h2>
            ) : (
              <div className="relative aspect-[2.2/1.25] md:aspect-[4/2.25] w-40 md:w-45">
                <Image
                  src={navData.logo}
                  alt="The Anantharaa Hotel Logo"
                  fill
                  priority
                  className="object-cover rounded-md"
                />
              </div>
            )}
          </div>
          {/* nav */}
          {/* <ul className="lg:flex border hidden border-white/15 bg-white/10 backdrop-blur-lg  rounded-full items-center  ml-36 w-fit nav">
            {navData.links.map((link, index) => (
              <li key={index}>
                <button
                  onClick={() => scrollToSection(link.href)}
                  type="button"
                  className="text-white px-5 py-2.5 "
                >
                  {link.label}
                </button>
              </li>
            ))}
          </ul> */}
          {/* BUTTON */}
          <ul className="flex items-center gap-2">
            {navButtons.map((link, index) => (
              <li key={index} className="flex items-center gap-2">
                <Link
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-2 rounded-lg px-2 md:px-6 py-2 md:py-3 ${index === 0 ? "bg-transparent text-p1 border border-p1" : "bg-p1 text-white"} font-semibold hover:scale-95 transition-all duration-300 ease-in-out hover:shadow-lg`}
                >
                  {index === 0 ? (
                    <span className="">
                      <CallIcon />
                    </span>
                  ) : (
                    <span className="">
                      <CalendarIcon />
                    </span>
                  )}
                  <span className="lg:block text-base hidden tracking-widest">
                    {link.label}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default LandingNavbar;
