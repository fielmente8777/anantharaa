"use client";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Container } from "../sectionComponants";
import { footerData, footerData2 } from "./footerdata";

const LandingFooter = () => {
  const pathName = usePathname();
  if (pathName === "/thank-you/") {
    return null;
  }
  const isLp2 = pathName.replace(/\/$/, "") === "/sonagiriserene";
  const data = isLp2 ? footerData2 : footerData;
  // const data =
  //   pathName.replace(/\/$/, "") === "/lp-2" ? footerData2 : footerData;
  return (
    <footer className="max_screen_width bg-p2 text-white">
      <Container>
        <div className="grid md:py-14 py-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-[1fr_.7fr_.5fr] gap-12 md:gap-16">
          <div className=" flex flex-col w-full lg:max-w-xl gap-6">
            {/* <div
              className={`relative 
                  w-35 aspect-[4/2.35] md:w-58 bg-white`}
            >
              <Image
                src={data.logo}
                alt="logo"
                fill
                sizes="100%"
                className="object-cover"
              />
            </div> */}
            <div
              className={`relative w-35 aspect-[4/2.35] md:w-58 ${
                isLp2 ? "mx-auto md:mx-0" : "bg-white"
              }`}
            >
              {isLp2 ? (
                <div className="flex w-full justify-center items-center">
                  <h2 className="flex flex-col items-center text-center font-secondary text-[#F7F3EB] text-3xl md:text-4xl font-medium ">
                    <span>SONAGIRI</span>

                    <span className="w-[45%] h-[1px] bg-[#F7F3EB]/70 my-1 md:my-1.5" />

                    <span className="font-inter text-[#F7F3EB] text-sm md:text-base font-medium tracking-[0.28em]">
                      SERENE
                    </span>
                  </h2>
                </div>
              ) : (
                <Image
                  src={data.logo}
                  alt="logo"
                  fill
                  sizes="100%"
                  className="object-cover"
                />
              )}
            </div>
          </div>

          {data.lists.map((list, index) => (
            <div className={` flex flex-col gap-4`} key={index}>
              <h2
                className="uppercase text-white/60 tracking-widest"
                dangerouslySetInnerHTML={{ __html: list.title ?? "" }}
              />
              <ul className={`flex flex-col md:gap-2 gap-4`}>
                {list.links.map((item, suIndex) => (
                  <li key={suIndex}>
                    {/* <span
                      className={`mt-1 ${
                        index === 1
                          ? "text-white flex items-center justify-center rounded-sm bg-white w-10 aspect-square"
                          : "text-white inline-block"
                      }`}
                    >
                      {item.icon}
                      <span className="sr-only">{item.label}</span>
                    </span> */}
                    {/* {item.title && (
                      <span
                        className={`${
                          index === 1
                            ? "text-white font-aboreto text-2xl my-auto"
                            : "md:text-lg text-white inline-block"
                        }`}
                      >
                        {item.title}
                      </span>
                    )} */}
                    {item.href ? (
                      <Link
                        target="_blank"
                        rel="noopener noreferrer"
                        href={item.href}
                        className=" text-sm"
                      >
                        <span className={` text-white/80 inline-block`}>
                          {item.label}
                        </span>
                      </Link>
                    ) : (
                      <span className={` text-white/80 text-sm`}>
                        {item.title}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="bg-white/10 h-px w-full" />
      </Container>
      <Container className="py-4 flex max-md:flex-col items-center gap-3.5 justify-between">
        <div className="md:flex max-md:space-x-2 text-center flex-wrap items-center justify-center gap-2 text-white text-sm">
          {" "}
          <span className="text-white/50">
            © {new Date().getFullYear()} Anantharaa Hotel.
          </span>
          <span className="text-white/50">All Rights Reserved.</span>
          {/* <span className="md:block hidden">|</span> */}
        </div>
        <p className="text-white/50 max-md:text-center text-sm">
          Powered by {""}
          <Link href="https://www.fielmente.com/" target="_blank">
            Fielmente
          </Link>
        </p>
      </Container>
    </footer>
  );
};

export default LandingFooter;
